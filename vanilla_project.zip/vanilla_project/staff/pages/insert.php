<?php
include_once 'db.php';
if(isset($_POST['submit']))
{    
     $name = $_POST['name'];
     $registration = $_POST['registration'];
     $school = $_POST['school'];
     $yearofstudy = $_POST['yearofstudy'];
     $amount = $_POST['amount'];
     $schoolbankaccount = $_POST['bankaccount'];
     $ward = $_POST['ward'];
     $location = $_POST['location'];
 
     $sql = "INSERT INTO awards (name,registration,school,yearofstudy,amount,bankaccount,ward,location)
     VALUES ('$name','$registration','$school','$yearofstudy','$amount','$schoolbankaccount','$ward','$location')";
     $result=mysqli_query($conn,$sql);
 
     if ($result) {
        $msg= "You have awarded successfully !";
     } else {
        $msg= "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>


