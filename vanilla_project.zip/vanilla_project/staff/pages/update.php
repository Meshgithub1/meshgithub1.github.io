<?php
include_once 'db.php';
if(isset($_POST['submit']))
{    
     $email = $_POST['email'];
     $phone = $_POST['phone'];
     $subject = $_POST['subject'];
     $message = $_POST['message'];
     
 
     $sql = "INSERT INTO updated (email,phone,subject,message)
     VALUES ('$email','$phone','$subject','$message')";
     $result=mysqli_query($conn,$sql);
 
     if ($result) {
        $msg= "You have submitted successfully !";
     } else {
        $msg= "Error: " . $sql . ":-" . mysqli_error($conn);
     }
     mysqli_close($conn);
}
?>


