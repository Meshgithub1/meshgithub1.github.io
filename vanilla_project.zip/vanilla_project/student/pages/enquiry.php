<?php

class uploader {
   public $db;
   private $action;

   public function __construct($dbc=null) {
      // If no database object is passed, create a new db connection
      if( !is_object($dbc) ) {
         $this->db = new mysqli('localhost', 'root', 'mesh', 'bursary');
         if ( mysqli_connect_errno() ) {
           return $this->error("DB Connection Error: ". mysqli_connect_error());
         }
      }
      // else assign the connection object to the passed connection
      else {
         $this->db = $dbc;
      }
      // If the session is not started yet
      if( !isset($_SESSION) ) {
         session_start();
      }
   }

   //_______________________________________________________________________________________________________________________________________
   public function getPostedValue($fieldName){
      if (isset($_POST[$fieldName])){
         $s = $_POST[$fieldName];
      }
      else {
         $s = '';
      }
      return $s;
   }

   //__________________________________________________________________________________________________________________
   public function doTheUpload(){
    $email = $this->getPostedValue('email');
    $phone= $this->getPostedValue('phone');
    $subject= $this->getPostedValue('subject');
    $message= $this->getPostedValue('message');
    


      echo "form submitted";

        //echo items
          /* echo "email : " . $email;
        
           
           echo "phone : " . $phone;
      
           
           echo "subject : " . $subject;
    
	  
           echo "message : " . $message;

           
           */
     
	  
      $sql = "insert into updated set email = '$email', phone = '$phone', subject = '$subject',message = '$message';" ;
      $result = $this->db->query($sql);
   }

}

$a = new uploader();
$a->doTheUpload();
?>